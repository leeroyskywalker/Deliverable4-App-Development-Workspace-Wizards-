package com.example.workspacewizardsg.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.repository.AuthRepository
import com.example.workspacewizardsg.repository.ClaimOutcome
import com.example.workspacewizardsg.repository.UserRepository
import com.example.workspacewizardsg.repository.WorkOrderRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CrewUiState(
    val crewName: String = "",
    val teamColour: String = "",
    val activeJob: WorkOrder? = null,
    val pendingJobs: List<WorkOrder> = emptyList(),
    val isLoading: Boolean = true,
    val isBusy: Boolean = false,
    val message: String? = null
)

class CrewViewModel(
    private val workOrderRepository: WorkOrderRepository = WorkOrderRepository(),
    userRepository: UserRepository = UserRepository(),
    authRepository: AuthRepository = AuthRepository()
) : ViewModel() {

    private val crewUserId: String? = authRepository.currentUser()?.uid

    private val _isBusy = MutableStateFlow(false)
    private val _message = MutableStateFlow<String?>(null)

    // .catch: after sign-out Firestore rejects open listeners, which must not crash the app
    val uiState: StateFlow<CrewUiState> = combine(
        (if (crewUserId == null) flowOf(null) else userRepository.observeUser(crewUserId))
            .catch { emit(null) },
        workOrderRepository.observeAllWorkOrders().catch { emit(emptyList()) },
        _isBusy,
        _message
    ) { user, orders, busy, message ->
        CrewUiState(
            crewName = user?.fullName.orEmpty(),
            teamColour = user?.teamColour.orEmpty(),
            activeJob = orders.firstOrNull {
                it.workOrderId == user?.activeJobId &&
                        it.status == "IN_PROGRESS" &&
                        it.assignedCrew == crewUserId
            },
            pendingJobs = orders.filter { it.status == "PENDING" },
            isLoading = false,
            isBusy = busy,
            message = message
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = CrewUiState()
    )

    fun takeJob(workOrderId: String) {
        val userId = crewUserId ?: return
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            workOrderRepository.claimWorkOrder(workOrderId, userId).fold(
                onSuccess = { outcome ->
                    _message.value = when (outcome) {
                        ClaimOutcome.CLAIMED -> null
                        ClaimOutcome.JOB_UNAVAILABLE -> "That job was just taken by another crew"
                        ClaimOutcome.CREW_BUSY -> "Finish your current job first"
                    }
                },
                onFailure = { _message.value = "Could not take the job. Check your connection." }
            )
            _isBusy.value = false
        }
    }

    fun completeJob() {
        val userId = crewUserId ?: return
        val job = uiState.value.activeJob ?: return
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            workOrderRepository.completeWorkOrder(job.workOrderId, userId)
                .onFailure { _message.value = "Could not complete the job. Check your connection." }
            _isBusy.value = false
        }
    }

    fun clearMessage() { _message.value = null }
}

