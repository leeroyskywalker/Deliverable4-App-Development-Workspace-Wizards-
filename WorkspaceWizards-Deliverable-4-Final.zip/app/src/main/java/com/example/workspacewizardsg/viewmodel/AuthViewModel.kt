package com.example.workspacewizardsg.viewmodel


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class AuthState {
    object Idle : AuthState()
    object Loading : AuthState()
    object MfaRequired : AuthState()
    data class Authenticated(val role: String) : AuthState()
    data class Error(val message: String) : AuthState()
}

class AuthViewModel(
    private val repository: AuthRepository = AuthRepository()
) : ViewModel() {

    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState

    // Held after step 1 succeeds, needed for role fetch and MFA logging
    private var pendingUserId: String? = null
    private var mfaStartTime: Long = 0L

    fun signIn(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _authState.value = AuthState.Error("Email and password are required")
            return
        }

        viewModelScope.launch {
            _authState.value = AuthState.Loading

            repository.signIn(email.trim(), password).fold(
                onSuccess = { user ->
                    pendingUserId = user.uid
                    mfaStartTime = System.currentTimeMillis()
                    _authState.value = AuthState.MfaRequired
                },
                onFailure = { e ->
                    _authState.value = AuthState.Error(
                        e.message ?: "Sign in failed. Check your credentials."
                    )
                }
            )
        }
    }

    fun verifyMfaCode(code: String) {
        val userId = pendingUserId ?: run {
            _authState.value = AuthState.Error("Session expired. Please sign in again.")
            return
        }

        if (code.length != 6 || !code.all { it.isDigit() }) {
            _authState.value = AuthState.Error("Enter a valid 6-digit code")
            return
        }

        viewModelScope.launch {
            _authState.value = AuthState.Loading

            val latency = System.currentTimeMillis() - mfaStartTime
            // Simulated TOTP: accepts "123456" — swap for real Firebase TOTP later
            val success = code == "123456"

            repository.logMfaAttempt(
                userId = userId,
                mfaType = "TOTP_SIMULATED",
                latencyMs = latency,
                success = success
            )

            if (success) {
                repository.getUserRole(userId).fold(
                    onSuccess = { role ->
                        _authState.value = AuthState.Authenticated(role)
                    },
                    onFailure = { e ->
                        _authState.value = AuthState.Error(
                            e.message ?: "Could not load user profile"
                        )
                    }
                )
            } else {
                _authState.value = AuthState.Error("Incorrect code. Please try again.")
            }
        }
    }
    fun signOut() {
        repository.signOut()
        _authState.value = AuthState.Idle
    }

    fun resetError() {
        if (_authState.value is AuthState.Error) {
            _authState.value = AuthState.Idle
        }
    }
}