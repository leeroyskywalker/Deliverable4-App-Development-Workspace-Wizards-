package com.example.workspacewizardsg.ui.theme

import androidx.compose.ui.graphics.Color

val Teal = Color(0xFF006D77)
val TealDark = Color(0xFF005B66)
val PinkAccent = Color(0xFFE21B63)
val BackgroundLight = Color(0xFFF8F9FA)
val SurfaceWhite = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1A1A1A)
val TextSecondary = Color(0xFF666666)
val BorderGrey = Color(0xFFE3E3E3)