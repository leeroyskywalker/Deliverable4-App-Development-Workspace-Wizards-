package com.example.workspacewizardsg.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.repository.WorkOrderRepository
import com.example.workspacewizardsg.util.MonthRevenue
import com.example.workspacewizardsg.util.buildFinancialSummary
import com.example.workspacewizardsg.util.completedRevenue
import com.example.workspacewizardsg.util.revenueByMonth
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class AnalyticsUiState(
    val isLoading: Boolean = true,
    val totalRevenue: Double = 0.0,
    val completedJobs: Int = 0,
    val months: List<MonthRevenue> = emptyList(),
    val summaryText: String = ""
)

class AnalyticsViewModel(
    workOrderRepository: WorkOrderRepository = WorkOrderRepository()
) : ViewModel() {

    val uiState: StateFlow<AnalyticsUiState> = workOrderRepository.observeAllWorkOrders()
        .catch { emit(emptyList()) }
        .map { orders -> toUiState(orders) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = AnalyticsUiState()
        )

    private fun toUiState(orders: List<WorkOrder>): AnalyticsUiState {
        val totalRevenue = completedRevenue(orders)
        val completedJobs = orders.count { it.status == "COMPLETED" }
        val months = revenueByMonth(orders)
        return AnalyticsUiState(
            isLoading = false,
            totalRevenue = totalRevenue,
            completedJobs = completedJobs,
            months = months,
            summaryText = buildFinancialSummary(totalRevenue, completedJobs, months)
        )
    }
}