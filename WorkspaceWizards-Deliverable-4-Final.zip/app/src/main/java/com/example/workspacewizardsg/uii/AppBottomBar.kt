package com.example.workspacewizardsg.uii

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector

// One place that defines every top-level page. The bottom bar and the drawer both read from here.
data class AppDestination(val route: String, val label: String, val icon: ImageVector)

val bottomBarItems = listOf(
    AppDestination("admin_dashboard", "Home", Icons.Default.Home),
    AppDestination("clients", "Clients", Icons.Default.Person),
    AppDestination("tasks", "Tasks", Icons.AutoMirrored.Filled.List),
    AppDestination("analytics", "Dashboard", Icons.Default.DateRange),
    AppDestination("search", "Search", Icons.Default.Search)
)

// Only in the drawer (not in the bottom bar)
val invoicesDestination = AppDestination("invoices", "Invoices", Icons.Default.Email)

val bottomBarRoutes: Set<String> = bottomBarItems.map { it.route }.toSet()

@Composable
fun AppBottomBar(currentRoute: String?, onNavigate: (String) -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        bottomBarItems.forEach { item ->
            NavigationBarItem(
                selected = currentRoute == item.route,
                onClick = { if (currentRoute != item.route) onNavigate(item.route) },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.tertiary,
                    selectedTextColor = MaterialTheme.colorScheme.tertiary,
                    indicatorColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f)
                )
            )
        }
    }
}