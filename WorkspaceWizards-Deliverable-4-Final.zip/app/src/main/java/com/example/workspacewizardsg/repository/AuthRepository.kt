package com.example.workspacewizardsg.repository

import com.example.workspacewizardsg.model.SecurityLog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class AuthRepository {

    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()

    suspend fun signIn(email: String, password: String): Result<FirebaseUser> {
        return try {
            val result = auth.signInWithEmailAndPassword(email, password).await()
            Result.success(result.user!!)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getUserRole(userId: String): Result<String> {
        return try {
            val doc = firestore.collection("users").document(userId).get().await()
            val role = doc.getString("role") ?: return Result.failure(
                Exception("Role not found for user")
            )
            Result.success(role)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun logMfaAttempt(
        userId: String,
        mfaType: String,
        latencyMs: Long,
        success: Boolean
    ) {
        try {
            val log = SecurityLog(
                userId = userId,
                mfaType = mfaType,
                latencyMs = latencyMs,
                success = success,
                timestamp = System.currentTimeMillis()
            )
            firestore.collection("securityLogs").add(log).await()
        } catch (e: Exception) {
            // Log silently — telemetry failure should never block the user
        }
    }

    fun signOut() {
        com.google.firebase.auth.FirebaseAuth.getInstance().signOut()
    }

    fun currentUser(): FirebaseUser? = auth.currentUser
}
