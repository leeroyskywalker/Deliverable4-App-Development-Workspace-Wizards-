package com.example.workspacewizardsg.util

import android.net.Uri
import com.example.workspacewizardsg.model.Invoice

// The WhatsApp text for an invoice, built from a fixed template (no AI involved).
fun buildInvoiceMessage(invoice: Invoice): String = buildString {
    appendLine("Hi ${invoice.clientName},")
    appendLine()
    appendLine("Your invoice from Workspace Wizards is ready.")
    appendLine()
    appendLine("Invoice: ${invoice.invoiceNumber}")
    appendLine("Service: ${invoice.serviceDetails}")
    appendLine("Site: ${invoice.siteAddress}")
    appendLine("Amount due: R%.2f".format(invoice.amountZAR))
    appendLine()
    appendLine("Pay by EFT:")
    appendLine("Account name: ${PaymentConfig.ACCOUNT_HOLDER}")
    appendLine("Bank: ${PaymentConfig.BANK_NAME}")
    appendLine("Account number: ${PaymentConfig.ACCOUNT_NUMBER}")
    appendLine("Branch code: ${PaymentConfig.BRANCH_CODE}")
    appendLine("Reference: ${invoice.invoiceNumber}")
    appendLine()
    append("Thank you for choosing Workspace Wizards.")
}

// WhatsApp click-to-chat link, or null when the client's phone number is not valid.
fun buildWhatsAppUrl(invoice: Invoice): String? {
    val phone = normaliseSaPhone(invoice.clientPhone) ?: return null
    val digitsOnly = phone.removePrefix("+")
    return "https://wa.me/$digitsOnly?text=${Uri.encode(buildInvoiceMessage(invoice))}"
}