package com.example.workspacewizardsg.uii

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workspacewizardsg.model.Client
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.viewmodel.WorkOrderViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateWorkOrderScreen(
    onNavigateBack: () -> Unit,
    viewModel: WorkOrderViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    var selectedClient by remember { mutableStateOf<Client?>(null) }
    var serviceDetails by remember { mutableStateOf("") }
    var amountInput by remember { mutableStateOf("") }
    var scheduledTime by remember { mutableStateOf("") }
    var clientDropdownExpanded by remember { mutableStateOf(false) }
    var formError by remember { mutableStateOf<String?>(null) }
    var isNewClient by remember { mutableStateOf(false) }
    var newCompany by remember { mutableStateOf("") }
    var newContact by remember { mutableStateOf("") }
    var newPhone by remember { mutableStateOf("") }
    var newAddress by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("New Work Order") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Client picker
            ExposedDropdownMenuBox(
                expanded = clientDropdownExpanded,
                onExpandedChange = { clientDropdownExpanded = it }
            ) {
                OutlinedTextField(
                    value = if (isNewClient) "New Client" else selectedClient?.companyName ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Client") },
                    placeholder = { Text("Select a client") },
                    trailingIcon = {
                        ExposedDropdownMenuDefaults.TrailingIcon(
                            expanded = clientDropdownExpanded
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )

                ExposedDropdownMenu(
                    expanded = clientDropdownExpanded,
                    onDismissRequest = { clientDropdownExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("+ New client") },
                        onClick = {
                            isNewClient = true
                            selectedClient = null
                            clientDropdownExpanded = false
                            formError = null
                        }
                    )
                    if (uiState.clients.isEmpty()) {
                        DropdownMenuItem(
                            text = { Text("No clients found") },
                            onClick = { clientDropdownExpanded = false }
                        )
                    } else {
                        uiState.clients.forEach { client ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(client.companyName)
                                        Text(
                                            text = client.siteAddress,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    selectedClient = client
                                    isNewClient = false
                                    clientDropdownExpanded = false
                                    formError = null
                                }
                            )
                        }
                    }
                }
            }
            if (isNewClient) {
                ClientField(newCompany, "Company name") { newCompany = it; formError = null }
                ClientField(newContact, "Contact person") { newContact = it; formError = null }
                ClientField(newPhone, "Phone (e.g. 082 123 4567)", KeyboardType.Phone) {
                    newPhone = it; formError = null
                }
                ClientField(newAddress, "Site address") { newAddress = it; formError = null }
            }

            // Selected client info — shown once a client is picked
            selectedClient?.let { client ->
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = MaterialTheme.shapes.medium
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = client.contactPerson,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = client.phone,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = client.siteAddress,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }

            OutlinedTextField(
                value = serviceDetails,
                onValueChange = {
                    serviceDetails = it
                    formError = null
                },
                label = { Text("Service details") },
                placeholder = { Text("Describe the job") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = amountInput,
                onValueChange = {
                    if (it.isEmpty() || it.matches(Regex("^\\d*\\.?\\d{0,2}$"))) {
                        amountInput = it
                        formError = null
                    }
                },
                label = { Text("Amount (ZAR)") },
                placeholder = { Text("0.00") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                prefix = { Text("R ") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = scheduledTime,
                onValueChange = {
                    scheduledTime = it
                    formError = null
                },
                label = { Text("Scheduled date & time") },
                placeholder = { Text("e.g. 2026-09-15 09:00") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            formError?.let {
                Text(
                    text = it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Button(
                onClick = {
                    val client = selectedClient
                    val amount = amountInput.toDoubleOrNull()
                    val phone = viewModel.normalisePhone(newPhone)

                    when {
                        !isNewClient && client == null ->
                            formError = "Please select a client"

                        isNewClient && (newCompany.isBlank() || newContact.isBlank() || newAddress.isBlank()) ->
                            formError = "Fill in all the client details"

                        isNewClient && phone == null ->
                            formError = "Enter a valid SA phone number"

                        isNewClient && viewModel.clientExists(newCompany, phone, uiState.clients) ->
                            formError = "This client already exists - pick them from the list"

                        serviceDetails.isBlank() ->
                            formError = "Service details are required"

                        amount == null || amount <= 0 ->
                            formError = "Enter a valid amount"

                        scheduledTime.isBlank() ->
                            formError = "Scheduled time is required"

                        else -> {
                            val target = client ?: Client(
                                companyName = newCompany.trim(),
                                contactPerson = newContact.trim(),
                                phone = phone ?: "",
                                siteAddress = newAddress.trim()
                            )
                            val order = WorkOrder(
                                clientId = target.clientId,
                                clientName = target.companyName,
                                clientPhone = target.phone,
                                siteAddress = target.siteAddress,
                                serviceDetails = serviceDetails.trim(),
                                amountZAR = amount,
                                scheduledTime = scheduledTime.trim()
                            )
                            if (isNewClient) viewModel.createWorkOrderWithNewClient(target, order)
                            else viewModel.createWorkOrder(order)
                            onNavigateBack()
                        }
                    }
                },
                enabled = !uiState.isLoading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Create Work Order")
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
    @Composable
    private fun ClientField(
        value: String,
        label: String,
        keyboardType: KeyboardType = KeyboardType.Text,
        onChange: (String) -> Unit
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            label = { Text(label) },
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
    }
