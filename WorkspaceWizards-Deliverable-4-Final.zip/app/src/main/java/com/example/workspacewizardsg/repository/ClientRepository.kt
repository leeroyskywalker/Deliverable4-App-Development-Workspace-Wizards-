package com.example.workspacewizardsg.repository

import com.example.workspacewizardsg.model.Client
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class ClientRepository {

    private val clientsCollection = FirebaseFirestore.getInstance().collection("clients")

    // Real-time stream of all clients for the picker dropdown
    fun observeClients(): Flow<List<Client>> = callbackFlow {
        val listener = clientsCollection
            .orderBy("companyName")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val clients = snapshot?.documents?.mapNotNull {
                    it.toObject(Client::class.java)
                } ?: emptyList()
                trySend(clients)
            }
        awaitClose { listener.remove() }
    }

    suspend fun addClient(client: Client): Result<String> {
        return try {
            val docRef = clientsCollection.add(client).await()
            // Write the generated ID back into the document
            clientsCollection.document(docRef.id)
                .update("clientId", docRef.id).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}