package com.example.workspacewizardsg.repository

import com.example.workspacewizardsg.model.Client
import com.example.workspacewizardsg.model.Invoice
import com.example.workspacewizardsg.model.WorkOrder
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

enum class ClaimOutcome { CLAIMED, JOB_UNAVAILABLE, CREW_BUSY }

class WorkOrderRepository {

    private val workOrdersCollection = FirebaseFirestore
        .getInstance().collection("workOrders")
    private val firestore = FirebaseFirestore.getInstance()
    private val usersCollection = firestore.collection("users")
    private val invoicesCollection = firestore.collection("invoices")
    private val countersCollection = firestore.collection("counters")

    // Real-time stream of all work orders, newest first
    fun observeAllWorkOrders(): Flow<List<WorkOrder>> = callbackFlow {
        val listener = workOrdersCollection
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                trySend(snapshot?.documents?.mapNotNull { it.toWorkOrder() } ?: emptyList())
            }
        awaitClose { listener.remove() }
    }

    fun observeWorkOrder(workOrderId: String): Flow<WorkOrder?> = callbackFlow {
        val listener = workOrdersCollection.document(workOrderId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                trySend(snapshot?.takeIf { it.exists() }?.toWorkOrder())
            }
        awaitClose { listener.remove() }
    }

    suspend fun updateWorkOrderDetails(
        workOrderId: String,
        siteAddress: String,
        serviceDetails: String,
        amountZAR: Double,
        scheduledTime: String
    ): Result<Unit> {
        return try {
            val problem = firestore.runTransaction<String?> { tx ->
                val ref = workOrdersCollection.document(workOrderId)
                val order = tx.get(ref)
                if (!order.exists()) return@runTransaction "This work order no longer exists"
                if (order.getString("status") == "COMPLETED") {
                    return@runTransaction "This job is already completed and can't be edited"
                }
                tx.update(
                    ref, mapOf(
                        "siteAddress" to siteAddress,
                        "serviceDetails" to serviceDetails,
                        "amountZAR" to amountZAR,
                        "scheduledTime" to scheduledTime
                    )
                )
                null
            }.await()
            if (problem == null) Result.success(Unit)
            else Result.failure(IllegalStateException(problem))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createWorkOrder(workOrder: WorkOrder): Result<String> {
        return try {
            val docRef = workOrdersCollection.add(workOrder).await()
            workOrdersCollection.document(docRef.id)
                .update("workOrderId", docRef.id).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteWorkOrder(workOrderId: String): Result<Unit> {
        return try {
            val problem = firestore.runTransaction<String?> { tx ->
                val orderRef = workOrdersCollection.document(workOrderId)
                val order = tx.get(orderRef)
                if (!order.exists()) return@runTransaction null // already gone

                val status = order.getString("status")
                if (status == "COMPLETED") return@runTransaction "Completed jobs can't be deleted"

                // Reads first, then writes: Firestore requires this order in a transaction
                var crewRef: DocumentReference? = null
                var crewSnapshot: DocumentSnapshot? = null
                val crewId = order.getString("assignedCrew")
                if (status == "IN_PROGRESS" && !crewId.isNullOrBlank()) {
                    crewRef = usersCollection.document(crewId)
                    crewSnapshot = tx.get(crewRef)
                }

                // Release the crew only if their pointer still refers to this job
                if (crewRef != null && crewSnapshot?.getString("activeJobId") == workOrderId) {
                    tx.update(crewRef, "activeJobId", null)
                }
                tx.delete(orderRef)
                null
            }.await()
            if (problem == null) Result.success(Unit)
            else Result.failure(IllegalStateException(problem))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createWorkOrderWithNewClient(client: Client, workOrder: WorkOrder): Result<String> {
        return try {
            val db = FirebaseFirestore.getInstance()
            val clientRef = db.collection("clients").document()
            val orderRef = workOrdersCollection.document()
            db.batch()
                .set(clientRef, client.copy(clientId = clientRef.id))
                .set(orderRef, workOrder.copy(workOrderId = orderRef.id, clientId = clientRef.id))
                .commit().await()
            Result.success(orderRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun claimWorkOrder(workOrderId: String, crewUserId: String): Result<ClaimOutcome> {
        return try {
            val outcome = firestore.runTransaction { tx ->
                val userRef = usersCollection.document(crewUserId)
                val orderRef = workOrdersCollection.document(workOrderId)

                // All reads first: Firestore requires reads before writes in a transaction
                val user = tx.get(userRef)
                val order = tx.get(orderRef)
                val currentJobId = user.getString("activeJobId")
                val currentJob = if (currentJobId.isNullOrBlank()) null
                else tx.get(workOrdersCollection.document(currentJobId))

                if (!order.exists() || order.getString("status") != "PENDING") {
                    return@runTransaction ClaimOutcome.JOB_UNAVAILABLE
                }

                // activeJobId is only a pointer: a deleted or finished job must not lock the crew out
                val hasLiveJob = currentJob != null && currentJob.exists() &&
                        currentJob.getString("status") == "IN_PROGRESS" &&
                        currentJob.getString("assignedCrew") == crewUserId
                if (hasLiveJob) return@runTransaction ClaimOutcome.CREW_BUSY

                tx.update(
                    orderRef, mapOf(
                        "status" to "IN_PROGRESS",
                        "assignedCrew" to crewUserId,
                        "assignedCrewName" to user.getString("fullName"),
                        "teamColour" to user.getString("teamColour")
                    )
                )
                tx.update(userRef, "activeJobId", workOrderId)
                ClaimOutcome.CLAIMED
            }.await()
            Result.success(outcome)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Completing a job and creating its invoice happen in ONE transaction:
    // a job can never be completed without an invoice, and never gets two.
    suspend fun completeWorkOrder(workOrderId: String, crewUserId: String): Result<Unit> {
        return try {
            val completed = firestore.runTransaction { tx ->
                val orderRef = workOrdersCollection.document(workOrderId)
                val invoiceRef = invoicesCollection.document(workOrderId) // same ID as the job
                val counterRef = countersCollection.document("invoices")

                // All reads first: Firestore requires reads before writes in a transaction
                val order = tx.get(orderRef)
                val existingInvoice = tx.get(invoiceRef)
                val counter = tx.get(counterRef)

                // Only the crew holding an in-progress job can complete it
                if (order.getString("status") != "IN_PROGRESS" ||
                    order.getString("assignedCrew") != crewUserId
                ) {
                    return@runTransaction false
                }

                tx.update(orderRef, "status", "COMPLETED")
                tx.update(usersCollection.document(crewUserId), "activeJobId", null)

                if (!existingInvoice.exists()) {
                    val nextNumber = (counter.getLong("last") ?: 0L) + 1
                    tx.set(counterRef, mapOf("last" to nextNumber))
                    tx.set(
                        invoiceRef,
                        Invoice(
                            invoiceId = workOrderId,
                            invoiceNumber = "INV-%04d".format(nextNumber),
                            workOrderId = workOrderId,
                            clientId = order.getString("clientId") ?: "",
                            clientName = order.getString("clientName") ?: "",
                            clientPhone = order.getString("clientPhone") ?: "",
                            siteAddress = order.getString("siteAddress") ?: "",
                            serviceDetails = order.getString("serviceDetails") ?: "",
                            amountZAR = order.getDouble("amountZAR") ?: 0.0,
                            paymentStatus = "UNPAID",
                            issuedDate = System.currentTimeMillis()
                        )
                    )
                }
                true
            }.await()

            if (completed) Result.success(Unit)
            else Result.failure(IllegalStateException("Job is no longer in progress"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

private fun DocumentSnapshot.toWorkOrder(): WorkOrder? = try {
    val createdAt = when (val raw = get("createdAt")) {
        is Timestamp -> raw.toDate().time
        is Number -> raw.toLong()
        else -> System.currentTimeMillis()
    }
    WorkOrder(
        workOrderId = getString("workOrderId") ?: id,
        clientId = getString("clientId") ?: "",
        clientName = getString("clientName") ?: "",
        clientPhone = getString("clientPhone") ?: "",
        siteAddress = getString("siteAddress") ?: "",
        serviceDetails = getString("serviceDetails") ?: "",
        amountZAR = getDouble("amountZAR") ?: 0.0,
        scheduledTime = getString("scheduledTime") ?: "",
        status = getString("status") ?: "PENDING",
        assignedCrew = getString("assignedCrew"),
        assignedCrewName = getString("assignedCrewName"),
        teamColour = getString("teamColour"),
        createdAt = createdAt
    )
} catch (e: Exception) {
    null // skip malformed documents rather than crashing
}