package com.example.workspacewizardsg.uii

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.viewmodel.WorkOrderDetailViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkOrderDetailScreen(
    onNavigateBack: () -> Unit,
    viewModel: WorkOrderDetailViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var showDeleteDialog by remember { mutableStateOf(false) }
    val order = uiState.workOrder
    val canModify = order != null && order.status != "COMPLETED"

    LaunchedEffect(uiState.deleted) {
        if (uiState.deleted) onNavigateBack()
    }
    LaunchedEffect(uiState.message) {
        uiState.message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Work Order") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (canModify) {
                        IconButton(
                            onClick = { showDeleteDialog = true },
                            enabled = !uiState.isDeleting
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete work order")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                uiState.isLoading ->
                    CircularProgressIndicator(Modifier.align(Alignment.Center))
                order == null ->
                    Text(
                        text = "This work order no longer exists.",
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(24.dp)
                    )
                uiState.isEditing ->
                    EditForm(
                        order = order,
                        isSaving = uiState.isSaving,
                        formError = uiState.formError,
                        onSave = viewModel::save,
                        onCancel = viewModel::cancelEditing
                    )
                else ->
                    DetailView(order = order, canModify = canModify, onEdit = viewModel::startEditing)
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete this work order?") },
            text = {
                Text(
                    if (order?.status == "IN_PROGRESS")
                        "This job is in progress. Deleting it will release " +
                                "${order.assignedCrewName ?: "the assigned crew"} so they can take another job."
                    else
                        "This can't be undone."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    viewModel.delete()
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun DetailView(order: WorkOrder, canModify: Boolean, onEdit: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = order.clientName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    StatusBadge(order.status)
                }
                DetailRow("Client phone", order.clientPhone)
                DetailRow("Site address", order.siteAddress)
                DetailRow("Service details", order.serviceDetails)
                DetailRow("Amount", "R %.2f".format(Locale.US, order.amountZAR))
                DetailRow("Scheduled", order.scheduledTime)
                order.assignedCrewName?.let { crew -> CrewRow(crew, order.teamColour) }
            }
        }

        if (canModify) {
            Button(onClick = onEdit, modifier = Modifier.fillMaxWidth()) { Text("Edit") }
        } else {
            Text(
                text = "Completed jobs can't be edited or deleted.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(text = value.ifBlank { "-" }, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun CrewRow(crewName: String, teamColour: String?) {
    val colour = teamColour?.let {
        runCatching { Color(android.graphics.Color.parseColor(it)) }.getOrNull()
    }
    Column {
        Text(
            text = "Assigned crew",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (colour != null) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .background(colour, CircleShape)
                )
                Spacer(Modifier.width(8.dp))
            }
            Text(text = crewName, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
private fun EditForm(
    order: WorkOrder,
    isSaving: Boolean,
    formError: String?,
    onSave: (siteAddress: String, serviceDetails: String, amount: String, scheduledTime: String) -> Unit,
    onCancel: () -> Unit
) {
    var siteAddress by remember { mutableStateOf(order.siteAddress) }
    var serviceDetails by remember { mutableStateOf(order.serviceDetails) }
    // Locale.US so the decimal separator is always "." and the amount parses back correctly
    var amountInput by remember { mutableStateOf(String.format(Locale.US, "%.2f", order.amountZAR)) }
    var scheduledTime by remember { mutableStateOf(order.scheduledTime) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Client: ${order.clientName}",
            style = MaterialTheme.typography.titleMedium
        )
        OutlinedTextField(
            value = siteAddress,
            onValueChange = { siteAddress = it },
            label = { Text("Site address") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = serviceDetails,
            onValueChange = { serviceDetails = it },
            label = { Text("Service details") },
            minLines = 3,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = amountInput,
            onValueChange = {
                if (it.isEmpty() || it.matches(Regex("^\\d*\\.?\\d{0,2}$"))) amountInput = it
            },
            label = { Text("Amount (ZAR)") },
            prefix = { Text("R ") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = scheduledTime,
            onValueChange = { scheduledTime = it },
            label = { Text("Scheduled date & time") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        formError?.let {
            Text(
                text = it,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Button(
            onClick = { onSave(siteAddress, serviceDetails, amountInput, scheduledTime) },
            enabled = !isSaving,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (isSaving) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            } else {
                Text("Save changes")
            }
        }
        OutlinedButton(
            onClick = onCancel,
            enabled = !isSaving,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Cancel") }
    }
}

