package com.example.workspacewizardsg.util

import com.example.workspacewizardsg.model.WorkOrder

// Returns the work orders that match the search text. An empty search returns every order.
// The status is matched by its readable name, so "pending" or "in progress" both work.
fun searchWorkOrders(orders: List<WorkOrder>, query: String): List<WorkOrder> {
    val term = query.trim()
    if (term.isEmpty()) return orders

    return orders.filter {
        it.clientName.contains(term, ignoreCase = true) ||
                it.clientPhone.contains(term, ignoreCase = true) ||
                it.siteAddress.contains(term, ignoreCase = true) ||
                it.serviceDetails.contains(term, ignoreCase = true) ||
                it.status.replace("_", " ").contains(term, ignoreCase = true) ||
                (it.assignedCrewName?.contains(term, ignoreCase = true) == true)
    }
}