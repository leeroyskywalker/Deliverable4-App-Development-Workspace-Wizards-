package com.example.workspacewizardsg.model

// Document ID = the work order ID, so a job can only ever have one invoice.
// The job details are copied onto the invoice so it never changes if the job is edited later.
data class Invoice(
    val invoiceId: String = "",
    val invoiceNumber: String = "",     // INV-0001, INV-0002, ...
    val workOrderId: String = "",
    val clientId: String = "",
    val clientName: String = "",
    val clientPhone: String = "",
    val siteAddress: String = "",
    val serviceDetails: String = "",
    val amountZAR: Double = 0.0,
    val paymentStatus: String = "UNPAID", // UNPAID or PAID
    val pdfUrl: String = "",              // unused until PDF generation is added
    val issuedDate: Long = 0L,            // epoch milliseconds
    val paidAt: Long? = null
)