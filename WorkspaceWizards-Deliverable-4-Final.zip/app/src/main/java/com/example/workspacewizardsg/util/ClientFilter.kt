package com.example.workspacewizardsg.util

import com.example.workspacewizardsg.model.Client

// Returns the clients that match the search text (company, contact, phone or address),
// sorted A to Z by company name. An empty search returns every client.
fun filterAndSortClients(clients: List<Client>, query: String): List<Client> {
    val term = query.trim()
    val matches = if (term.isEmpty()) {
        clients
    } else {
        clients.filter {
            it.companyName.contains(term, ignoreCase = true) ||
                    it.contactPerson.contains(term, ignoreCase = true) ||
                    it.phone.contains(term, ignoreCase = true) ||
                    it.siteAddress.contains(term, ignoreCase = true)
        }
    }
    return matches.sortedBy { it.companyName.lowercase() }
}

