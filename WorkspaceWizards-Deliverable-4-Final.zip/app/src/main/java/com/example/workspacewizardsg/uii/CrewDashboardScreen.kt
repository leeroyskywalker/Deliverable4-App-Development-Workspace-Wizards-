package com.example.workspacewizardsg.uii

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.viewmodel.CrewViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrewDashboardScreen(
    onSignOut: () -> Unit,
    viewModel: CrewViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var showCompleteDialog by remember { mutableStateOf(false) }

    // Solid team colour for the top bar, a light tint of it for the page background
    val teamColour = parseTeamColour(uiState.teamColour) ?: MaterialTheme.colorScheme.primary
    val onTeamColour = if (teamColour.luminance() > 0.5f) Color.Black else Color.White
    val pageTint = teamColour.copy(alpha = 0.12f).compositeOver(MaterialTheme.colorScheme.background)

    LaunchedEffect(uiState.message) {
        uiState.message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        containerColor = pageTint,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(uiState.crewName.ifBlank { "Field Crew" }) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = teamColour,
                    titleContentColor = onTeamColour,
                    actionIconContentColor = onTeamColour
                ),
                actions = {
                    IconButton(onClick = onSignOut) {
                        Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Sign out")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize().padding(innerPadding),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(innerPadding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                uiState.activeJob?.let { job ->
                    item { SectionTitle("Your active job") }
                    item {
                        JobCard(
                            job = job,
                            maxDetailLines = Int.MAX_VALUE,
                            buttonLabel = "Complete Job",
                            buttonEnabled = !uiState.isBusy,
                            onButtonClick = { showCompleteDialog = true }
                        )
                    }
                }

                item { SectionTitle("Available jobs") }
                if (uiState.activeJob != null) {
                    item {
                        Text(
                            text = "Finish your current job to take another.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (uiState.pendingJobs.isEmpty()) {
                    item {
                        Text(
                            text = "No jobs available right now",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(uiState.pendingJobs, key = { it.workOrderId }) { job ->
                        JobCard(
                            job = job,
                            maxDetailLines = 3,
                            buttonLabel = "Take This Job",
                            buttonEnabled = uiState.activeJob == null && !uiState.isBusy,
                            onButtonClick = { viewModel.takeJob(job.workOrderId) }
                        )
                    }
                }
            }
        }
    }

    if (showCompleteDialog) {
        AlertDialog(
            onDismissRequest = { showCompleteDialog = false },
            title = { Text("Complete this job?") },
            text = { Text("The job will be marked as completed. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    showCompleteDialog = false
                    viewModel.completeJob()
                }) { Text("Complete") }
            },
            dismissButton = {
                TextButton(onClick = { showCompleteDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text = text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
}

@Composable
private fun JobCard(
    job: WorkOrder,
    maxDetailLines: Int,
    buttonLabel: String,
    buttonEnabled: Boolean,
    onButtonClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = job.clientName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(text = job.siteAddress, style = MaterialTheme.typography.bodyMedium)
            Text(
                text = job.serviceDetails,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = maxDetailLines,
                overflow = TextOverflow.Ellipsis
            )
            Text(text = "Scheduled: ${job.scheduledTime}", style = MaterialTheme.typography.labelMedium)
            Text(text = "Client phone: ${job.clientPhone}", style = MaterialTheme.typography.labelMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = onButtonClick,
                enabled = buttonEnabled,
                modifier = Modifier.fillMaxWidth()
            ) { Text(buttonLabel) }
        }
    }
}

private fun parseTeamColour(hex: String): Color? =
    runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrNull()

