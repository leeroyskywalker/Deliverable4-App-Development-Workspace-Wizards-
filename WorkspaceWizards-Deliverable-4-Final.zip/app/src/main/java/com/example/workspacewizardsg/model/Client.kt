package com.example.workspacewizardsg.model

data class Client(
    val clientId: String = "",
    val companyName: String = "",
    val contactPerson: String = "",
    val phone: String = "",
    val siteAddress: String = ""
)