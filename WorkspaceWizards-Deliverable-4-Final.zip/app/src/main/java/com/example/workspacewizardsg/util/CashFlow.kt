package com.example.workspacewizardsg.util

import com.example.workspacewizardsg.model.WorkOrder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class MonthRevenue(val label: String, val amount: Double)

// Revenue = the total of all completed work orders.
fun completedRevenue(orders: List<WorkOrder>): Double =
    orders.filter { it.status == "COMPLETED" }.sumOf { it.amountZAR }

// Completed revenue for each of the last `months` calendar months, oldest first.
// Uses createdAt because there is no completedAt field yet (known limitation).
fun revenueByMonth(orders: List<WorkOrder>, months: Int = 6): List<MonthRevenue> {
    val completed = orders.filter { it.status == "COMPLETED" }
    val labelFormat = SimpleDateFormat("MMM", Locale.getDefault())

    return ((months - 1) downTo 0).map { monthsAgo ->
        val start = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.MONTH, -monthsAgo)
        }
        val end = (start.clone() as Calendar).apply { add(Calendar.MONTH, 1) }

        MonthRevenue(
            label = labelFormat.format(start.time),
            amount = completed
                .filter { it.createdAt >= start.timeInMillis && it.createdAt < end.timeInMillis }
                .sumOf { it.amountZAR }
        )
    }
}

// Plain-text report that the Share button hands to WhatsApp, email, etc.
fun buildFinancialSummary(
    totalRevenue: Double,
    completedJobs: Int,
    months: List<MonthRevenue>,
    generatedAt: Date = Date()
): String {
    val dateText = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(generatedAt)
    return buildString {
        appendLine("Workspace Wizards - Financial Summary")
        appendLine("Generated: $dateText")
        appendLine()
        appendLine("Completed jobs: $completedJobs")
        appendLine("Total revenue: R%.2f".format(totalRevenue))
        // Placeholder: replace with the real figure when invoices are built
        appendLine("Outstanding receivables: not available yet")
        appendLine()
        appendLine("Revenue by month (completed jobs):")
        append(months.joinToString("\n") { "${it.label}: R%.2f".format(it.amount) })
    }
}