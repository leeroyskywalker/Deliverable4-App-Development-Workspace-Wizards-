package com.example.workspacewizardsg.model

import com.google.firebase.Timestamp

data class WorkOrder(
    val workOrderId: String = "",
    val clientId: String = "",
    val clientName: String = "",
    val clientPhone: String = "",
    val siteAddress: String = "",
    val serviceDetails: String = "",
    val amountZAR: Double = 0.0,
    val scheduledTime: String = "",
    val status: String = "PENDING",
    val assignedCrew: String? = null,
    val assignedCrewName: String? = null,
    val teamColour: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

