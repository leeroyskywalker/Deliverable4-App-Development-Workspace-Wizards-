package com.example.workspacewizardsg.uii

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workspacewizardsg.model.Invoice
import com.example.workspacewizardsg.viewmodel.InvoicesViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun InvoicesScreen(
    onNavigateBack: () -> Unit,
    onHome: () -> Unit,
    viewModel: InvoicesViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var invoiceToMarkPaid by remember { mutableStateOf<Invoice?>(null) }

    // Show any error once, then clear it
    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.clearError()
        }
    }

    Scaffold(
        topBar = { AppTopBar(title = "Invoices", onBack = onNavigateBack, onHome = onHome) },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                uiState.isLoading -> CircularProgressIndicator(Modifier.align(Alignment.Center))

                uiState.invoices.isEmpty() -> Text(
                    text = "No invoices yet.\nCompleting a job creates its invoice.",
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(horizontal = 32.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                else -> LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item(key = "unpaid_summary") {
                        UnpaidSummary(
                            total = viewModel.unpaidTotal(uiState.invoices),
                            count = viewModel.unpaidCount(uiState.invoices)
                        )
                    }
                    items(items = uiState.invoices, key = { it.invoiceId }) { invoice ->
                        InvoiceCard(
                            invoice = invoice,
                            canSendWhatsApp = viewModel.whatsAppUrl(invoice) != null,
                            onSendWhatsApp = {
                                viewModel.whatsAppUrl(invoice)?.let { openLink(context, it) }
                            },
                            onMarkPaid = { invoiceToMarkPaid = invoice }
                        )
                    }
                }
            }
        }
    }

    invoiceToMarkPaid?.let { invoice ->
        AlertDialog(
            onDismissRequest = { invoiceToMarkPaid = null },
            title = { Text("Mark as paid?") },
            text = {
                Text("${invoice.invoiceNumber} for ${invoice.clientName} (R%.2f) will be marked as paid.".format(invoice.amountZAR))
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.markAsPaid(invoice.invoiceId)
                    invoiceToMarkPaid = null
                }) { Text("Mark as paid") }
            },
            dismissButton = {
                TextButton(onClick = { invoiceToMarkPaid = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun UnpaidSummary(total: Double, count: Int) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Unpaid",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "R%.2f".format(total),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.tertiary
            )
            Text(
                text = "$count unpaid invoice${if (count == 1) "" else "s"}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun InvoiceCard(
    invoice: Invoice,
    canSendWhatsApp: Boolean,
    onSendWhatsApp: () -> Unit,
    onMarkPaid: () -> Unit
) {
    val isPaid = invoice.paymentStatus == "PAID"

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = invoice.invoiceNumber,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                PaymentBadge(isPaid = isPaid)
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = invoice.clientName, style = MaterialTheme.typography.bodyMedium)
            Text(
                text = invoice.serviceDetails,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Issued ${formatDate(invoice.issuedDate)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "R %.2f".format(invoice.amountZAR),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            if (!canSendWhatsApp) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Client phone number is not valid, so WhatsApp is unavailable.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onSendWhatsApp, enabled = canSendWhatsApp) {
                    Text("Send on WhatsApp")
                }
                if (!isPaid) {
                    Button(onClick = onMarkPaid) { Text("Mark as paid") }
                }
            }
        }
    }
}

@Composable
private fun PaymentBadge(isPaid: Boolean) {
    val (label, color) = if (isPaid) "Paid" to Color(0xFF10B981) else "Unpaid" to Color(0xFFF59E0B)
    Surface(shape = RoundedCornerShape(20.dp), color = color.copy(alpha = 0.15f)) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = color
        )
    }
}

private fun formatDate(epochMillis: Long): String =
    SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(epochMillis))

// The wa.me link opens WhatsApp when installed, otherwise the browser.
private fun openLink(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: ActivityNotFoundException) {
        // No app can open the link; nothing more to do
    }
}