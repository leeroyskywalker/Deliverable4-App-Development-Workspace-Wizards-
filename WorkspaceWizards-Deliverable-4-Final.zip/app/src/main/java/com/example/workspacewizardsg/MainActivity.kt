package com.example.workspacewizardsg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.workspacewizardsg.ui.LoginScreen
import com.example.workspacewizardsg.ui.theme.WorkspaceWizardsGTheme
import com.example.workspacewizardsg.uii.AdminDashboardScreen
import com.example.workspacewizardsg.uii.AppBottomBar
import com.example.workspacewizardsg.uii.AppDrawerContent
import com.example.workspacewizardsg.uii.ClientsScreen
import com.example.workspacewizardsg.uii.CreateWorkOrderScreen
import com.example.workspacewizardsg.uii.CrewDashboardScreen
import com.example.workspacewizardsg.uii.PlaceholderScreen
import com.example.workspacewizardsg.uii.WorkOrderDetailScreen
import com.example.workspacewizardsg.uii.bottomBarRoutes
import com.example.workspacewizardsg.uii.drawerRoutes
import com.example.workspacewizardsg.viewmodel.AuthViewModel
import kotlinx.coroutines.launch
import com.example.workspacewizardsg.uii.TasksScreen
import com.example.workspacewizardsg.uii.AnalyticsScreen
import com.example.workspacewizardsg.uii.SearchScreen
import com.example.workspacewizardsg.uii.InvoicesScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WorkspaceWizardsGTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    AppNavigation(
                        modifier = Modifier
                            .padding(innerPadding)
                            .consumeWindowInsets(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
private fun AppNavigation(modifier: Modifier = Modifier) {
    val navController = rememberNavController()
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
    val authViewModel: AuthViewModel = viewModel()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val signOut: () -> Unit = {
        authViewModel.signOut()
        navController.navigate("login") {
            popUpTo(navController.graph.id) { inclusive = true }
        }
    }

    // Used by the bottom bar, the drawer, the Order Status button and the home icon.
    val navigateTopLevel: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo("admin_dashboard")
            launchSingleTop = true
        }
    }
    val goHome: () -> Unit = { navigateTopLevel("admin_dashboard") }
    val goBack: () -> Unit = { navController.popBackStack() }

    // The drawer can only be opened (button or swipe) on the admin top-level pages.
    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = currentRoute in drawerRoutes,
        drawerContent = {
            AppDrawerContent(
                currentRoute = currentRoute,
                onNavigate = { route ->
                    scope.launch { drawerState.close() }
                    navigateTopLevel(route)
                },
                onSignOut = {
                    scope.launch { drawerState.close() }
                    signOut()
                }
            )
        }
    ) {
        Scaffold(
            modifier = modifier,
            bottomBar = {
                if (currentRoute in bottomBarRoutes) {
                    AppBottomBar(
                        currentRoute = currentRoute,
                        onNavigate = navigateTopLevel
                    )
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = "login",
                modifier = Modifier.padding(innerPadding)
            ) {
                composable("login") {
                    LoginScreen(
                        onAuthenticated = { role ->
                            val destination = if (role == "Admin") "admin_dashboard"
                            else "crew_dashboard"
                            navController.navigate(destination) {
                                popUpTo("login") { inclusive = true }
                            }
                        }
                    )
                }

                composable("admin_dashboard") {
                    AdminDashboardScreen(
                        onOpenMenu = { scope.launch { drawerState.open() } },
                        onCreateWorkOrder = { navController.navigate("create_work_order") },
                        onOrderStatus = { navigateTopLevel("tasks") },
                        onWorkOrderTapped = { workOrderId ->
                            navController.navigate("work_order_detail/$workOrderId")
                        }
                    )
                }

                composable("clients") {
                    ClientsScreen(
                        onNavigateBack = goBack,
                        onHome = goHome
                    )
                }

                composable("tasks") {
                    TasksScreen(
                        onNavigateBack = goBack,
                        onHome = goHome,
                        onWorkOrderTapped = { workOrderId ->
                            navController.navigate("work_order_detail/$workOrderId")
                        }
                    )
                }
                composable("analytics") {
                    AnalyticsScreen(onNavigateBack = goBack, onHome = goHome)
                }
                composable("search") {
                    SearchScreen(
                        onNavigateBack = goBack,
                        onHome = goHome,
                        onWorkOrderTapped = { workOrderId ->
                            navController.navigate("work_order_detail/$workOrderId")
                        }
                    )
                }
                composable("invoices") {
                    InvoicesScreen(onNavigateBack = goBack, onHome = goHome)
                }

                composable("create_work_order") {
                    CreateWorkOrderScreen(onNavigateBack = goBack)
                }

                composable("crew_dashboard") {
                    CrewDashboardScreen(onSignOut = signOut)
                }

                composable("work_order_detail/{workOrderId}") {
                    WorkOrderDetailScreen(onNavigateBack = goBack)
                }
            }
        }
    }
}

